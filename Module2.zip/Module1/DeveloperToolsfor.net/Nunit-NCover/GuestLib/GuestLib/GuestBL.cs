using System;
using System.Collections.Generic;
using System.Text;

namespace GuestLib
{
    public class GuestBL
    {
        private static List<Guest> guestList = null;

        public static List<Guest> Instance()
        {
            if (guestList == null)
                guestList = new List<Guest>();
            return guestList;
        }

        public bool AddGuest(Guest guestDetails)
        {
            bool result = false;
            int oldCount = guestList.Count;
            guestList.Add(guestDetails);
            int newCount = guestList.Count;
            if (newCount > oldCount)
                result = true;
            return result;
        }

        public bool UpdateGuest(Guest guestDetails)
        {
            bool result = false;
            int guestIndex = -1;
            for (int i = 0; i < guestList.Count; i++)
            {
                if (guestList[i].GuestID == guestDetails.GuestID)
                    guestIndex = i;
            }
            guestList[guestIndex].GuestName = guestDetails.GuestName;
            guestList[guestIndex].PhoneNumber = guestDetails.PhoneNumber;
            guestList[guestIndex].Title = guestDetails.Title;
            result = true;
            return result;
        }

        public Guest GetGuestByID(int guestID)
        {
            Guest guestDetails = new Guest();
            int guestIndex = -1;
            for (int i = 0; i < guestList.Count; i++)
            {
                if (guestList[i].GuestID == guestID)
                    guestIndex = i;
            }
            if (guestIndex != -1 && guestList != null)
            {
                guestDetails = guestList[guestIndex];
            }
            else
            {
                throw new GuestException("Guest with this ID Not Exists");
            }
            return guestDetails;
        }


        public bool DeleteGuest(int guestID)
        {
            bool result = false;
            int oldCount = guestList.Count;
            int guestIndex = -1;
            for (int i = 0; i < guestList.Count; i++)
            {
                if (guestList[i].GuestID == guestID)
                    guestIndex = i;
            }
            if (guestIndex != -1 && guestList != null)
            {
                guestList.RemoveAt(guestIndex);
            }
            else
            {
                throw (new GuestException("Guest with this ID is not Exists"));
            }

            int newCount = guestList.Count;
            if (newCount < oldCount)
                result = true;
            return result;
        }

        public List<Guest> GetAllGuests()
        {
            return guestList;

        }
    }
}
