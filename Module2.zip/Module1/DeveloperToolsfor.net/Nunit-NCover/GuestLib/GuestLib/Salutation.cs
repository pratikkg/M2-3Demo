using System;
using System.Collections.Generic;
using System.Text;

namespace GuestLib
{
    public enum Salutation
    {
        Mr = 0,
        Ms = 1,
        Mrs = 2,
        Dr = 3
    }
}
