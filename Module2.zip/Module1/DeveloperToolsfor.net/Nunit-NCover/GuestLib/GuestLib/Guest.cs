using System;
using System.Collections.Generic;
using System.Text;

namespace GuestLib
{
    public class Guest
    {
        private int guestID;

        public int GuestID
        {
            get { return guestID; }
            set { guestID = value; }
        }
        private string guestName;

        public string GuestName
        {
            get { return guestName; }
            set { guestName = value; }
        }
        private string phoneNumber;

        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }
        private Salutation title;

        public Salutation Title
        {
            get { return title; }
            set { title = value; }
        }
        private List<Guest> guests;

        public List<Guest> Guests
        {
            get { return guests; }
            set { guests = value; }
        }


        public Guest()
        {

        }

        public Guest(int guestID, Salutation title, string guestName, string phoneNumber)
        {
            this.guestID = guestID;
            this.title = title;
            this.guestName = guestName;
            this.phoneNumber = phoneNumber;
        }
    }
}
