using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using GuestLib;
using NUnit.Framework.SyntaxHelpers;

namespace GuestTest
{
    [TestFixture]
    public class GuestBLTest
    {
        private GuestBL guestBL = null;
        private List<Guest> guestInstance = null;

        [SetUp]
        public void SetUp()
        {
            guestBL = new GuestBL();
            guestInstance = GuestBL.Instance();
        }

        [Test]
        public void Test01()
        {
            Assert.IsInstanceOfType(typeof(List<Guest>), guestInstance);
        }

        [Test]
        public void Test02()
        {
            Guest guest= new Guest();
            guest.GuestID = 101;
            guest.GuestName = "Karthik";
            guest.Title  = Salutation.Mr;
            guest.PhoneNumber = "9841701459";
            bool guestAdded = guestBL.AddGuest(guest);
            Assert.IsTrue(guestAdded);
        }


        [Test]
        public void Test03()
        {
            Guest guest = guestInstance[0];
            guest.GuestID = 101;
            guest.GuestName = "Novendu";
            guest.Title = Salutation.Mr;
            guest.PhoneNumber = "9841150212";
            bool guestUpdated = guestBL.UpdateGuest(guest);
            Assert.IsTrue(guestUpdated);
        }


        [Test]
        public void Test04()
        {
            Guest searchGuest = guestInstance[0];
            Guest foundGuest = guestBL.GetGuestByID(101);
            Assert.AreSame(searchGuest, foundGuest);
        }

        [Test]
      //  [ExpectedException(typeof(GuestException))]
        public void Test05()
        {
            try
            {
                Guest searchGuest = guestInstance[0];
                Guest foundGuest = guestBL.GetGuestByID(102);
            }
            catch (GuestException ex)
            {
                Assert.AreEqual("Guest with this ID Not Exists", ex.Message);
            }
        }


        [Test]
        public void Test06()
        {
            List<Guest> guests = guestBL.GetAllGuests();
            Assert.That(guests.Count, Is.EqualTo(1));
        }

        [Test]
        public void Test07()
        {
            List<Guest> guests = guestBL.GetAllGuests();
            bool guestDeleted = guestBL.DeleteGuest(guests[0].GuestID);
            Assert.IsTrue(guestDeleted);
        }


        [Test]
        public void Test08()
        {
            try
            {
                bool guestDeleted = guestBL.DeleteGuest(101);
            }
            catch (GuestException ex)
            {
                Text.Equals("Guest with this ID is not Exists", ex.Message);
            }
        }

        [TearDown]
        public void TearDown()
        {
            guestBL = null;
        }


    }
}
