using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using GuestLib;

namespace GuestTest
{
    [TestFixture]
    public class GuestExceptionTest
    {
        [Test]
        [ExpectedException(typeof(GuestException))]
        public void Test01()
        {
            throw new GuestException();
        }

        [Test]
        public void Test02()
        {
            try
            {
                throw new GuestException("Sample Message");
            }
            catch (GuestException ex)
            {
                Assert.AreEqual("Sample Message", ex.Message);
            }
        }
    }
}
