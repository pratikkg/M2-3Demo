using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using Demo05;
using System.Reflection;

namespace Demo05Test
{
    [TestFixture]
    public class SampleTest
    {
        [Test]
        public void Test01()
        {
            Assembly a = Assembly.GetAssembly(typeof(Sample));
            Type type = a.GetType("Demo05.Sample");
            object obj = a.CreateInstance("Demo05.Sample");
            FieldInfo f = type.GetField("testNo", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.AreEqual(7, (int)f.GetValue(obj));

            MethodInfo m = type.GetMethod("AddNos", BindingFlags.Instance | BindingFlags.NonPublic);
            int actual = (int)m.Invoke(obj, new object[] { 4, 5 });
            int expected = 9;
            Assert.AreEqual(expected, actual);

            /*
            Type type = typeof(Demo05.Sample);
            Sample sampleObj = (Demo05.Sample)type.GetConstructor(Type.EmptyTypes).Invoke(null);
           
            int field = (int)type.GetField("testNo",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(sampleObj);
            Assert.AreEqual(7, field);

            int actual = (int)type.GetMethod("AddNos",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(sampleObj, new object[] { 4, 5 });
            int expected = 9;
            Assert.AreEqual(expected, actual);*/

        }
    }
}
