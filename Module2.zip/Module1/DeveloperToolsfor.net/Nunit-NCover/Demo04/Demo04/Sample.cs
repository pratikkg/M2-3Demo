using System;
using System.Collections.Generic;
using System.Text;

namespace Demo04
{
    /// <summary>
    /// Testing protected methods
    /// </summary>
    public class Sample
    {
        protected int AddNos(int a, int b)
        {
            return a + b;
        }
        public static int MultiplyNos(int a, int b)
        {
            return a * b;

        }
    }
}
