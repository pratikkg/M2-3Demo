using System;
using System.Collections.Generic;
using System.Text;

namespace Demo03
{
    public class Employee
    {
        private int employeeID;

        /// <summary>
        /// Gets or sets the employee ID.
        /// </summary>
        /// <value>The employee ID.</value>
        public int EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        private string employeeName;

        /// <summary>
        /// Gets or sets the name of the employee.
        /// </summary>
        /// <value>The name of the employee.</value>
        public string EmployeeName
        {
            get { return employeeName; }
            set { employeeName = value; }
        }

        /// <summary>
        /// Initializes a new instance of the Employee class.
        /// </summary>
        public Employee()
        {

        }

        /// <summary>
        /// Initializes a new instance of the Employee" class.
        /// </summary>
        /// <param name="employeeID">The employee ID.</param>
        /// <param name="employeeName">Name of the employee.</param>
        public Employee(int employeeID,string employeeName)
        {
            this.employeeID = employeeID;
            this.employeeName = employeeName;
        }
    }
}
