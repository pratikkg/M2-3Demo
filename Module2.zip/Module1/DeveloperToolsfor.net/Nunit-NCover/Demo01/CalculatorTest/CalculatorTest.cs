using System;
using System.Collections.Generic;
using System.Text;

using Demo01;
using NUnit.Framework;

namespace CalculatorTest
{
    [TestFixture]
    public class CalculatorTest
    {
        private Calculator calc = null;

        [SetUp]
        public void SetUp()
        {
            calc = new Calculator();
        }

        [Test]
        public void AddNumbers()
        {
            int actual = calc.AddNumbers(6, 7);
            int expected = 13;
            Assert.AreEqual(expected,actual);
        }

        [Test]
        public void SubtractNumbers()
        {
            int expected = calc.SubtractNumbers(12, 7);
            int actual = 5;
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void MultiplyNumbers()
        {
            int expected = calc.MultiplyNumbers(2, 7);
            int actual = 14;
            Assert.AreEqual(expected, actual);
        }

        [Test]
        [Category("Exception Test Cases")]
        [ExpectedException(typeof(DivideByZeroException))]
        public void DivideNumberswithException()
        {
            int expected = calc.DivideNumbers(12, 0);
            //Assert.AreEqual(expected, actual);
        }

        [Test]
        //[Ignore("Test later")]
        public void DivideNumbers()
        {
            int expected = calc.DivideNumbers(12, 2);
            int actual = 6;
            Assert.AreEqual(expected, actual);
            //Assert.That(expected, Is.GreaterThanOrEqualTo(actual));
        }

        [TearDown]
        public void TearDown()
        {
            calc = null;
        }
    }
}
