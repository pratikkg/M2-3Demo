﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovarianceDemoFramework3
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }

        public Employee(int empID, string name)
        {
            EmpID = empID;
            EmpName = name;
        }
    }

    public class Manager : Employee
    {
        public int Allowance { get; set; }

        public Manager(int empID, string name, int all)
            : base(empID, name)
        {
            Allowance = all;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IList<Manager> mgr = new List<Manager>();

            mgr.Add(new Manager(101, "Robert", 2000));
            mgr.Add(new Manager(102, "Jenny", 3000));
            mgr.Add(new Manager(103, "Jason", 2000));
            mgr.Add(new Manager(104, "Walt", 5000));

            Employee e = new Manager(1,"abc",789);

            IEnumerable<Employee> emp = mgr;

            foreach (Manager m in emp)
            {
                Console.WriteLine("Employee ID : " + m.EmpID + " Employee Name : " + m.EmpName + " Allowance : " + m.Allowance);
            }
        }
    }
}
