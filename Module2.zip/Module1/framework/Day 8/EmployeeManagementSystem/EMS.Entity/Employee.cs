﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Description : This class will have the Employee Structure
    /// Date of Creation : 
    /// </summary>
    [Serializable]
    public class Employee
    {
        //Get or Set Employee ID
        public int EmployeeID { get; set; }

        //Get or Set Employee Name
        public string EmployeeName { get; set; }

        //Get or Set Phone Number
        public string Phone { get; set; }

        //Get or Set Age
        public int Age { get; set; }

        //Get or Set Date of Joining
        public DateTime DOJ { get; set; }

        //Get or Set Location
        public string Location { get; set; }
    }
}
