﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;       //Reference to Entity Classes
using EMS.Exception;    //Reference to Exception Classes
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace EMS.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Description : Employee operations class to deal with the Employee data
    /// Date of Creation : 
    /// </summary>
    public class EmployeeOperations
    {
        static List<Employee> empList = new List<Employee>();

        //Method for adding new employee in employee list
        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = false;

            try 
            {
                //Adding Employee in list
                empList.Add(emp);
                empAdded = true;
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

        //Method for updating employee details in employee list
        public static bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;

            try 
            {
                for (int i = 0; i < empList.Count; i++)
                {
                    //Finding the employee using employee id
                    if (empList[i].EmployeeID == emp.EmployeeID)
                    {
                        //updating employee details
                        empList[i].EmployeeName = emp.EmployeeName;
                        empList[i].Phone = emp.Phone;
                        empList[i].Age = emp.Age;
                        empList[i].DOJ = emp.DOJ;
                        empList[i].Location = emp.Location;
                        empUpdated = true;
                    }
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        //Method for deleting the employee details from employee list
        public static bool DeleteEmployee(int empID)
        {
            bool empDeleted = false;

            try 
            {
                //Search employee from the list
                Employee emp = empList.Find(e => e.EmployeeID == empID);

                //Delete the employee from the list
                if (emp != null)
                {
                    empList.Remove(emp);
                    empDeleted = true;
                }
                else
                {
                    throw new EmployeeException("Employee not found for Deletion");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        //Method for displaying all employees
        public static List<Employee> DisplayAllEmployee()
        {
            return empList;
        }

        //Method for searching employee from list
        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try 
            {
                //Searching Employee ID
                emp = empList.Find(e => e.EmployeeID == empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try 
            {
                if (empList.Count > 0)
                {
                    FileStream fs = new FileStream("Employee.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, empList);
                    fs.Close();
                    empSerialized = true;
                }
                else
                {
                    throw new EmployeeException("No Employee Data, so cannot serialize");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> desEmpList = null;

            try 
            {
                FileStream fs = new FileStream("Employee.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desEmpList = (List<Employee>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desEmpList;
        }
    }
}
