﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo file = new FileInfo(@"D:\DATA\2017\Jan 2017\BatchInfo.txt");

            if (file.Exists)
            {
                Console.WriteLine("File Name is : " + file.Name);
                Console.WriteLine("File Creation Time is : " + file.CreationTime);
                Console.WriteLine("File Directory Name is : " + file.Directory.Name);
                Console.WriteLine("File Directory Name is : " + file.DirectoryName);
                Console.WriteLine("File Extension is : " + file.Extension);
                Console.WriteLine("File Full Name is : " + file.FullName);
                Console.WriteLine("File is Read Only : " + file.IsReadOnly);
                Console.WriteLine("File Last Access Time : " + file.LastAccessTime);
                Console.WriteLine("File Last Write Time : " + file.LastWriteTime);
                Console.WriteLine("File Length is : " + file.Length);
                
            }
            else
            {
                Console.WriteLine("File does not exists");
            }

            Console.ReadKey();
        }
    }
}
