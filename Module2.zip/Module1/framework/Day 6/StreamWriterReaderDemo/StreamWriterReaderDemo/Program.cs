﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StreamWriterReaderDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream("stream.txt", FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(12345);
            sw.WriteLine(".NET Batch");
            sw.WriteLine(false);
            sw.WriteLine(Math.PI);
            sw.WriteLine(DateTime.Now.ToString());
            sw.Flush();
            fs.Close();

            FileStream fsRead = new FileStream("stream.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fsRead);
            string data = sr.ReadToEnd();
            Console.WriteLine(data);
            fsRead.Close();
        }
    }
}
