﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(101);

            //emp.EmployeeID = 102;     Error - It is readonly
            emp.EmployeeName = "Robert";
            emp.DOB = Convert.ToDateTime("02/02/1967");

            Console.WriteLine("Employee ID : " + emp.EmployeeID);
            Console.WriteLine("Employee Name : " + emp.EmployeeName);
            //Console.WriteLine("Date of Birth : " + emp.DOB); Error - Get accessor not there

            Console.ReadKey();
        }
    }
}
