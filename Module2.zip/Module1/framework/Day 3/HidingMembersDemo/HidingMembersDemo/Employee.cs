﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HidingMembersDemo
{
    public class Employee
    {
        public void Show()
        {
            Console.WriteLine("Employee Class Show Method");
        }

        public void Display()
        {
            Console.WriteLine("Employee Class Display Method");
        }
    }
}
