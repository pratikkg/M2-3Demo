﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo
{
    public class Employee
    {
        public Employee()
        {
            Console.WriteLine("Default Constructor of Employee Class");
        }

        public Employee(string name)
        {
            Console.WriteLine("Parameterized Constructor of Employee Class");
        }

        static Employee()
        {
            Console.WriteLine("Static Constructor of Employee Class");
        }
    }
}
