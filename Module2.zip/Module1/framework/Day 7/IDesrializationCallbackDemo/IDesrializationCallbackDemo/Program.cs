﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace IDesrializationCallbackDemo
{
    [Serializable]
    public class Student : IDeserializationCallback
    {
        int studID;
        string studName;
        int marks1;
        int marks2;
        int marks3;
        [NonSerialized]
        int total;
        [NonSerialized]
        int percentage;

        public Student(int studID, string studName, int marks1, int marks2, int marks3)
        {
            this.studID = studID;
            this.studName = studName;
            this.marks1 = marks1;
            this.marks2 = marks2;
            this.marks3 = marks3;
            this.total = marks1 + marks2 + marks3;
            this.percentage = total * 100 / 300;
        }

        public int StudentID {
            get { return studID; }
            set { studID = value; }
        }

        public string StudentName {
            get { return studName; }
            set { studName = value; }
        }

        public int Marks1 {
            get { return marks1; }
            set { marks1 = value; }
        }

        public int Marks2 {
            get { return marks2; }
            set { marks2 = value; }
        }

        public int Marks3 {
            get { return marks3; }
            set { marks3 = value; }
        }

        public int Total {
            get { return total; }
        }

        public int Percentage {
            get { return percentage; }
        }

        public void CalculateMarks()
        {
            total = marks1 + marks2 + marks3;
            percentage = total * 100 / 300;
        }

        void IDeserializationCallback.OnDeserialization(object sender)
        {
            CalculateMarks();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Student stud = new Student(101, "Vidisha", 76, 83, 67);
            FileStream fs = new FileStream("student.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();

            bin.Serialize(fs, stud);
            Console.WriteLine("Serialization Completed");
            fs.Close();

            fs = new FileStream("student.txt", FileMode.Open, FileAccess.Read);
            Student studData = (Student)bin.Deserialize(fs);
            Console.WriteLine("Deserialization Completed");
            fs.Close();

            Console.WriteLine("Student ID : " + studData.StudentID);
            Console.WriteLine("Student Name : " + studData.StudentName);
            Console.WriteLine("Marks 1 : " + studData.Marks1);
            Console.WriteLine("Marks 2 : " + studData.Marks2);
            Console.WriteLine("Marks 3 : " + studData.Marks3);
            Console.WriteLine("Total Marks : " + studData.Total);
            Console.WriteLine("Percentage : " + studData.Percentage);
            
            Console.ReadKey();
        }
    }
}
