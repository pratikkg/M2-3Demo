﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace HashTableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hs = new Hashtable();

            hs.Add(1, ".NET");
            hs.Add(2, "Java");
            hs.Add(3, "V & V");
            hs.Add(4, "Mainframe");
            hs.Add(5, ".NET");
            hs.Add(6, "BI");

            
            Console.WriteLine("Hash Table Data : ");
            foreach (var key in hs.Keys)
            {
                Console.WriteLine("Key : " + key + " Value : " + hs[key].ToString());
            }
        }
    }
}
