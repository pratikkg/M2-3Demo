﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstraintsDemo
{
    public class MyClass<T> where T: class
    { }

    public class Customer { }

    public struct DOB { }
    class Program
    {
        static void Main(string[] args)
        {
            MyClass<int> intObj = new MyClass<int>();

            MyClass<DOB> dobObj = new MyClass<DOB>();

            MyClass<float> floatObj = new MyClass<float>();

            MyClass<string> strObj = new MyClass<string>();

            MyClass<Customer> custObj = new MyClass<Customer>();
        }
    }
}
