﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DaysofTheWeek week = new DaysofTheWeek();

            foreach (string day in week)
            {
                Console.WriteLine(day);    
            }

            Console.ReadKey();
        }
    }
}
