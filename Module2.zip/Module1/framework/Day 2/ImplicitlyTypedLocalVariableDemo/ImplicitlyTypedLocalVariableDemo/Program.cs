﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitlyTypedLocalVariableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var num = 10;

            Console.WriteLine(num);
            //num = "Capgemini"; Error : Cannot convert string to int

            //var val;    Error: Implicitly Typed Local Variables must be initialized

            //var val = null; Error : Cannot assign null to implicitly typed local variable

            //var val = { 1, 2, 3 }; Error : Cannot assign with array initializer

            var val = "Capgemini";
            val = null;

            Console.ReadKey();
        }
    }
}
