﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceImplementation
{
    public interface IMyInterface1
    {
        void Show();
        void Display();
    }
}
