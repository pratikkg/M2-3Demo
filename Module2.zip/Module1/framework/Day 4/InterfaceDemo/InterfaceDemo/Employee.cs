﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    public class Employee : IPrintable
    {
        public void Print()
        {
            Console.WriteLine("Print Method of Employee Class");
        }

        public void Display()
        {
            Console.WriteLine("Display Method of Employee Class");
        }
    }
}
