﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Entity;
using CustomException;

namespace DataAccessLayer
{
    /// <summary>
    /// Class containing database code
    /// Author: Mr. Nachiket Inamdar
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public class GuestOperations
    {
        SqlConnection connection;
        SqlDataReader reader;
       
        public GuestOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["GMS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method to add customer record
        /// Author: Mr. Nachiket Inamdar
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="guestObj"></param>
        /// <returns>bool</returns>
        public bool AddGuestRecord(Guest guestObj)
        {
            try
            {
                bool guestAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddGuest", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@GuestID", guestObj.GuestID);
                cmdAdd.Parameters.AddWithValue("@GuestName", guestObj.GuestName);
                cmdAdd.Parameters.AddWithValue("@ContactNo", guestObj.ContactNo);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    guestAdded = true;
                return guestAdded;
            }
            catch (GuestException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
        
        /// <summary>
        /// Method to return Guest information
        /// Author: Mr. Nachiket Inamdar
        /// Date Modified: 8th march 2017
        /// Version No: 
        /// </summary>
        /// <param name="guestID"></param>
        /// <returns></returns>
        public DataTable GetGuestRecord(int guestID)
        {
            SqlCommand cmdGetGuest = new SqlCommand("RetrieveGuestInfo", connection);
            cmdGetGuest.CommandType = CommandType.StoredProcedure;
            cmdGetGuest.Parameters.AddWithValue("@GuestID", guestID);
            if(connection.State==ConnectionState.Closed)
                connection.Open();
            reader = cmdGetGuest.ExecuteReader();
            DataTable  guestTable = new DataTable();
            guestTable.Load(reader);
            return guestTable;
        }
    }
}
