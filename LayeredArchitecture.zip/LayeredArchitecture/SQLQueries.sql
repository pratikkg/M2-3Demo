CREATE TABLE Guest
(
	GuestID int PRIMARY KEY,
	GuestName varchar(30),
	ContactNo bigint
)

CREATE PROCEDURE AddGuest
(
	@GuestID int,
	@GuestName varchar(30),
	@ContactNo bigint
)
AS
INSERT INTO Guest
VALUES(@GuestID,@GuestName,@ContactNo)

EXEC AddGuest 1002,'Ajinkya Rahane',9988775985


CREATE PROCEDURE GetAllGuests
AS
SELECT * FROM Guest

EXEC GetAllGuests

CREATE PROCEDURE RetrieveGuestInfo
(
	@GuestID int
)
AS
SELECT * FROM Guest
WHERE GuestID=@GuestID

EXEC RetrieveGuestInfo 1001

