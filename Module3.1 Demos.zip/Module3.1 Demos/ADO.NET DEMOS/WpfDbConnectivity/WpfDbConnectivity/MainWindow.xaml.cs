﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WpfDbConnectivity
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["Training"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand cmdCategories = new SqlCommand("Select * From dbo.Categories", connection);
            SqlDataReader categoriesReader = null;
            connection.Open();
            categoriesReader = cmdCategories.ExecuteReader();
            DataTable categoriesTable = new DataTable();
            categoriesTable.Load(categoriesReader);
            this.DataContext = categoriesTable;
        }
    }
}
